package com.cg.lab14.service;
import com.cg.lab14.dao.IEmployeeDao;
import com.cg.lab14.dao.IEmployeeDaoImpl;
import com.cg.lab14.dto.Employee;


//@Component("employeeservice")
public class IEmployeeServiceImpl implements IEmployeeService 
{
	//@Autowired
	IEmployeeDaoImpl empdao;
	public IEmployeeDaoImpl getEmpdao() {
		return empdao;
	}
	public void setEmpdao(IEmployeeDaoImpl empdao) {
		this.empdao = empdao;
	}

	@Override
	public Employee getEmployeeDetails(int empId) 
	{
		return empdao.getEmployeeDetails(empId);
	} 

	

}
