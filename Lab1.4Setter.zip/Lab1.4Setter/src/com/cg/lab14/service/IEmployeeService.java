package com.cg.lab14.service;

import com.cg.lab14.dto.Employee;

public interface IEmployeeService
{
	Employee getEmployeeDetails(int empId);
}
