package com.cg.lab14.dao;

import java.util.List;
import com.cg.lab14.dto.Employee;

//@Component("employeedao")
public class IEmployeeDaoImpl implements IEmployeeDao 
{
	
	/*@Autowired
	Employee emp;*/
	
	List<Employee> emp;
	
	public List<Employee> getEmp() {
		return emp;
	}

	public void setEmp(List<Employee> emp) {
		this.emp = emp;
	}

	@Override
	public Employee getEmployeeDetails(int empId) 
	{
		Employee ee=null;
		
		for(Employee e:emp)
		{
			if(e.getEmpId() == empId)
			{
				ee=e;
			}
			else
			{
				//System.out.println(" empId not correct");
				 ;
			}
		}
		return ee;
	}

	
}
