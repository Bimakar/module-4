package com.cg.lab14.dao;

import com.cg.lab14.dto.Employee;

public interface IEmployeeDao 
{
	Employee getEmployeeDetails(int empId);
}
