package com.cg.lab14.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab14.dto.Employee;
import com.cg.lab14.service.IEmployeeService;
import com.cg.lab14.service.IEmployeeServiceImpl;

public class Test {

	public static void main(String[] args)
	{
		
		ApplicationContext app = new ClassPathXmlApplicationContext("beans.xml");
		
		IEmployeeServiceImpl ies=(IEmployeeServiceImpl)app.getBean("employeeservice");
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee id for which details is to be searched");
		int empId=sc.nextInt();
		Employee e1 = ies.getEmployeeDetails(empId);

		System.out.println(e1.toString());
		
		

	}

}
