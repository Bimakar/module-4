package com.cg.lab14.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.lab14.dao.IEmployeeDao;
import com.cg.lab14.dao.IEmployeeDaoImpl;
import com.cg.lab14.dto.Employee;


//@Component("employeeservice")
public class IEmployeeServiceImpl implements IEmployeeService 
{
	
	IEmployeeDaoImpl empdao;
	
	public IEmployeeDaoImpl getEmpdao() {
		return empdao;
	}

	public void setEmpdao(IEmployeeDaoImpl empdao) {
		this.empdao = empdao;
	}

	@Override
	public Employee getEmployeeDetails(int empId) 
	{
		
		return empdao.getEmployeeDetails(empId);
	}
	//@Autowired
	//IEmployeeDao employeedao; 

	

}
