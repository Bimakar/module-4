package com.cg.lab1.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab1.dto.SBU;



public class Test {

	public static void main(String[] args) 
	{
ApplicationContext app= new ClassPathXmlApplicationContext("Spring.xml");
		
		SBU e=(SBU)app.getBean("sbu");
		
		e.getAllEmployeeDetails();

	}

}
