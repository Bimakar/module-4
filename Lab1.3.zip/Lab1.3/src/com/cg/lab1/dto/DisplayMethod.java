package com.cg.lab1.dto;

public interface DisplayMethod 
{
	public void getAllEmployeeDetails();
}
