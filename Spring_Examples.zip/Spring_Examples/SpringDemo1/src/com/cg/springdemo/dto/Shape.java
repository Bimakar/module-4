package com.cg.springdemo.dto;

public interface Shape 
{
	public void getShape();
}
