package com.cg.springdemo.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemo.dto.Employee;
import com.cg.springdemo.dto.Shape;



public class MyTest {

	public static void main(String[] args) 
	{
		
		ApplicationContext app = new ClassPathXmlApplicationContext("Spring.xml");
		
		Shape sp=(Shape)app.getBean("triangle");
		Employee d=(Employee)app.getBean("emp");
		//triangle is the id name from xml file
		
		Shape sp1=(Shape)app.getBean("circle");	
		sp.getShape();
		sp1.getShape();
		d.getAllDetails();
		
	}

}
