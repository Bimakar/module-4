package co.cg.Springspel.dto;

public class PrintEmployeeDetails 
{
	String fullName;
	double takeHomeSalary;
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public double getTakeHomeSalary() {
		return takeHomeSalary;
	}
	public void setTakeHomeSalary(double takeHomeSalary) {
		this.takeHomeSalary = takeHomeSalary;
	}
	
	public void getAllDetails()
	{
		System.out.println("Full Name "+fullName);
		System.out.println("Take home Salary "+takeHomeSalary);
		
	}
	
}
