package co.cg.Springspel.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import co.cg.Springspel.dto.PrintEmployeeDetails;

public class MyMain 
{

	public static void main(String[] args) 
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("Spring6.xml");
		
		PrintEmployeeDetails ped=(PrintEmployeeDetails)app.getBean("print");
		ped.getAllDetails();
	}

}
