package com.cg.lab14.service;

public interface IEmployeeService
{
	public void getEmployeeData();
}
