package com.cg.lab14.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.lab14.dao.IEmployeeDao;


@Component("employeeservice")
public class IEmployeeServiceImpl implements IEmployeeService 
{
	@Autowired
	IEmployeeDao employeedao; 

	@Override
	public void getEmployeeData() 
	{
		System.out.println("Service layer  ");
		employeedao.getEmployeeData();

	}

}
