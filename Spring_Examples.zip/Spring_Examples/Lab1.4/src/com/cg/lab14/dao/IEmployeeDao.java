package com.cg.lab14.dao;

public interface IEmployeeDao 
{
	public void getEmployeeData();
}
