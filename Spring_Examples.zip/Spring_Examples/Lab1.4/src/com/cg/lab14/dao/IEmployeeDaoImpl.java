package com.cg.lab14.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.lab14.dto.Employee;

@Component("employeedao")
public class IEmployeeDaoImpl implements IEmployeeDao 
{
	
	@Autowired
	Employee emp;
	
	@Override
	public void getEmployeeData() 
	{
		
		System.out.println("Employee Dao.........");
		emp.getAllDetails();
	}

}
