package com.cg.lab14.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab14.service.IEmployeeService;

public class Test {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int empId;
		String empName;
		double salary;
		
		System.out.println("Enter employee id");
		empId=sc.nextInt();
		System.out.println("Enter employee name");
		empName=sc.next();
		System.out.println("Enter employee salary");
		salary=sc.nextDouble();
		
		
		ApplicationContext app = new ClassPathXmlApplicationContext("beans.xml");
		
		IEmployeeService ies=(IEmployeeService)app.getBean("employeeservice");
		ies.getEmployeeData();

	}

}
