package com.cg.springdemo2.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemo2.dto.EmployeeDetail;

public class MyTest {

	public static void main(String[] args) 
	{
		ApplicationContext app= new ClassPathXmlApplicationContext("String.xml");
		
		EmployeeDetail e=(EmployeeDetail)app.getBean("emp");
		
		e.getAllEmployeeDetails();

	}

}




/*
 * ways of wrting Constructor injection in xml file:
 * 
 * <constructor-arg index="0" value="1001"></constructor-arg>
<constructor-arg index="1" value="ABCD"></constructor-arg>
<constructor-arg name="empName" value="Gupta"></constructor-arg>
<constructor-arg type="String" value="Rishita"></constructor-arg>

<bean id="emp" class="com.cg.springdemo2.dto.Employee"> agar srif ye line likhi hoti toh default constructor call hota
*/