package com.cg.springdemo2.dto;

public class Employee implements EmployeeDetail
{
	int empId;
	String empName;

	public Employee() 
	{
		super();
	}

	public Employee(int empId, String empName) 
	{
		super();
		this.empId = empId;
		this.empName = empName;
	}




	@Override
	public void getAllEmployeeDetails() 
	{
		System.out.println("Id is : "+empId);
		System.out.println("Name is : "+empName);
		
	}

}
