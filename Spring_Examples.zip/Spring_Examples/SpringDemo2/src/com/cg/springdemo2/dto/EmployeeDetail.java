package com.cg.springdemo2.dto;

public interface EmployeeDetail
{
	public void getAllEmployeeDetails();
}
