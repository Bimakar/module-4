package com.cg.lab1.dto;

public class Employee implements DisplayMethod
{
	int employeeId;
	String employeeName;
	double salary;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public void getAllEmployeeDetails() {
		// TODO Auto-generated method stub
		
	}
	
	}
