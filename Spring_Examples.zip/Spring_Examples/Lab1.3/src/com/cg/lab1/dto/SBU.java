package com.cg.lab1.dto;

import java.util.List;

public class SBU implements DisplayMethod
{

	int sbuCode;
	String sbuName;
	String sbuHead;
	
	List<Employee> emp;
	
	
	public int getSbuCode() {
		return sbuCode;
	}


	public void setSbuCode(int sbuCode) {
		this.sbuCode = sbuCode;
	}


	public String getSbuName() {
		return sbuName;
	}


	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}


	public String getSbuHead() {
		return sbuHead;
	}


	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}


	public List<Employee> getEmp() {
		return emp;
	}


	public void setEmp(List<Employee> emp) {
		this.emp = emp;
	}


	@Override
	public void getAllEmployeeDetails() 
	{
		System.out.println("SBU Details");
		System.out.println("------------------------");
		System.out.println("SBU Code="+sbuCode+" , sbuHead="+sbuHead+" ,sbuName="+sbuName);
		System.out.println("Employee Deatils ");
		System.out.println("---------------------");
		for(Employee employee:emp)
		{
			System.out.println("Employee [empId="+employee.getEmployeeId()+
					" , empName="+employee.getEmployeeName()+
					" , empSalary="+employee.getSalary()+"]");
		}
		System.out.println("]");
		
	}

}
