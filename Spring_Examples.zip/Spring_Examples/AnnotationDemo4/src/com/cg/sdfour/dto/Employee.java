package com.cg.sdfour.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.sdfour.service.IEmployeeServive;

@Component("emp")
public class Employee 
{
	@Autowired
	IEmployeeServive employeeservice;		//always call by interface
	
	public void getDetails()
	{
		System.out.println(" Welcome to spring annotations.........");
		employeeservice.getData();
	}
}
