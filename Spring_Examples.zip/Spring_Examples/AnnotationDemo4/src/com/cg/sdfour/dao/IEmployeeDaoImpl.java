package com.cg.sdfour.dao;

import org.springframework.stereotype.Component;


@Component("employeedao")
public class IEmployeeDaoImpl implements IEmployeeDao
{

	@Override
	public void getDao() 
	{
		System.out.println("In Dao Class");
		
	}

}
