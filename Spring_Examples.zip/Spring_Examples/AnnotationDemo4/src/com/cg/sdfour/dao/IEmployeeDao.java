package com.cg.sdfour.dao;

public interface IEmployeeDao 
{
	public void getDao();
}
