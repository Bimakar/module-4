package com.cg.sdfour.service;

public interface IEmployeeServive 
{
	public void getData();
}
