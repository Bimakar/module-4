package com.cg.sdfour.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.sdfour.dao.IEmployeeDao;

@Component("employeeservice")
public class IEmployeeServiceImpl implements IEmployeeServive 
{
	@Autowired
	IEmployeeDao employeedao;

	@Override
	public void getData() 
	{
		// TODO Auto-generated method stub
		System.out.println("In service class");
		employeedao.getDao();
	}

}
