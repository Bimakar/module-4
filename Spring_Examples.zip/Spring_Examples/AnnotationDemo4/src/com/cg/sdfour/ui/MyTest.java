package com.cg.sdfour.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.sdfour.dto.Employee;

public class MyTest {

	public static void main(String[] args) 
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("Spring4.xml");
		Employee e=(Employee)app.getBean("emp");
		e.getDetails();

	}

}
/*
 * <context:component-scan base-package="com.cg.sdfour"></context:component-scan>	 
 * this is component annotation example
 * 
 * 
 * 
 * */
