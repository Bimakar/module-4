package com.cg.springdemo3.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springdemo3.dto.EmployeeDetails;



public class MyTest {

	public static void main(String[] args) 
	{
		ApplicationContext app= new ClassPathXmlApplicationContext("Spring.xml");
		
		EmployeeDetails e=(EmployeeDetails)app.getBean("emp");
		
		e.getAllEmployeeDetails();


	}

}

/*
 * <property name="proOne" ref="one"></property>
	<property name="proTwo" ref="two"></property>
 * 
 * 
 * */
