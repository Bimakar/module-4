package com.cg.springdemo3.dto;

import java.util.List;

public class Employee implements EmployeeDetails
{
	int empId;
	String empName;
	
	List<Project> pro;
	
	
	
	/*Project proOne;
	Project proTwo;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Project getProOne() {
		return proOne;
	}

	public void setProOne(Project proOne) {
		this.proOne = proOne;
	}

	public Project getProTwo() {
		return proTwo;
	}

	public void setProTwo(Project proTwo) {
		this.proTwo = proTwo;
	}*/

	public int getEmpId() {
		return empId;
	}



	public void setEmpId(int empId) {
		this.empId = empId;
	}



	public String getEmpName() {
		return empName;
	}



	public void setEmpName(String empName) {
		this.empName = empName;
	}



	public List<Project> getPro() {
		return pro;
	}



	public void setPro(List<Project> pro) {
		this.pro = pro;
	}



	@Override
	public void getAllEmployeeDetails() 
	{
		System.out.println("Id is : "+empId);
		System.out.println("Name is : "+empName);
		
		for(Project project:pro)
		{
			System.out.println("Project Id is : "+project.getProjId());
			System.out.println("Project name is : "+project.getProjName());
		}
		
		/*System.out.println("Project One Id is : "+proOne.getProjId());
		System.out.println("Project One Name is :   "+proOne.getProjName());
		
		System.out.println("Project two Id is : "+proTwo.getProjId());
		System.out.println("Project two Name is :   "+proTwo.getProjName());*/
		
	}

}
