package com.cg.springdemo3.dto;

public interface EmployeeDetails 
{
	public void getAllEmployeeDetails();
}
