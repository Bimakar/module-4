package com.cg.lab1.dto;

public class Employee 
{
	int employeeId;
	String employeeName;
	double salary;
	SBU businessUnit;
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public SBU getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(SBU businessUnit) {
		this.businessUnit = businessUnit;
	}
	
	
	public void getEmployeeDetails()
	{
		System.out.println("Employee [employeeId=" + employeeId + 
				", employeeName="+ employeeName + 
				", salary=" + salary + 
				"\n " + businessUnit.getSBUDetails());
	}
	
	
	
	

}
